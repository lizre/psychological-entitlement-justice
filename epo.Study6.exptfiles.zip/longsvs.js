define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest'});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
		required:true, 
          answers: [
                 {text: 'Extremely important',value:5},
                 {text: 'Very important',value:4},
                 {text: 'Somewhat important',value:2},
                 {text: 'Slightly important',value:1},
                 {text: 'Not important',value:0}
                  ]
		}]);
		
			
	    API.addQuestionsSet('Continue', [
		{type: 'selectOne',
		autoSubmit: true,
                noSubmit:true,
		numericValues:true, 
          answers: [
                 {text: 'To begin, click here, or click Submit below',value:1}
                 ]
		}]);
	
            API.addPagesSet('progressBar', [
	{progressBar: 'Please indicate how much you find these values important. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
			v1style:2}]);

        API.addPagesSet('progressBar2', [
	{progressBar: 'Please indicate how much you find these values important. To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: false,
			v1style:2}]);

		
API.addSequence([

               
{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'ssvspower4',
               required: true,
               stem: "How important is power as a life-guiding principle for you?"}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'ssvspower1',
               required: true,
               stem: "How important is social power as a life-guiding principle for you?"}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'ssvspower2',
               required: true,
               stem: "How important is authority as a life-guiding principle for you?"}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'ssvspower3',
               required: true,
               stem: "How important is wealth as a life-guiding principle for you?"}]},
	 

        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'ssvsachievement4',
               required: true,
               stem: "How important is achievement as a life-guiding principle for you?"}]},
               
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'ssvsachievement1',
               required: true,
               stem: "How important is achievement as a life-guiding principle for you?"}]},
               
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'ssvsachievement2',
               required: true,
               stem: "How important is personal capability/competence as a life-guiding principle for you?"}]},
               
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'ssvsachievement3',
               required: true,
               stem: "How important is ambition as a life-guiding principle for you?"}]}
    ]}]);

 
return API.script;
});



























