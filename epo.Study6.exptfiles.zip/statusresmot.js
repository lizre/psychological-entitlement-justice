define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest'});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
		required: true,
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1}
               ]
		}]);
	
	
    API.addPagesSet('progressBar', [
	{progressBar: 'To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true,
	    v1style:2
	}]);

	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'statusresmot1',
               required: true,
               stem: "Punishment should communicate to the offender that people have low regard for him or her."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'statusresmot2',
               required: true,
               stem: "Punishment should humiliate the offender."}]}
	 
    ]}]);

 
return API.script;
});








