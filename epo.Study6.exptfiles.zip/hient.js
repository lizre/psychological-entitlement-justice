define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest'});

    API.addPagesSet('progressBar', [
	{progressBar: '<h4><br><br>Now we would like you to take a certain perspective on yourself and respond accordlingly.',
numbered: false,
        decline: true,
			v1style:2}]);


API.addSequence([


        {inherit: 'progressBar',
         questions: [
            {type:'textarea',
            name: 'hient1',
            required: true,
               stem: "<p><br></b>First, we would like you to take the perspective that you should demand the best in life. Whether or not you actually believe this, or even if it seems difficult to believe, we would simply like you to imagine that it is true, and try your best to think of a reason for it and complete the following sentence: <br>I should demand the best in life because...",
                rows:1},

            {type:'textarea',
            name: 'hient2',
            required: true,
               stem: "<p><br></b>Next, we would like you to take the perspective that you deserve more than others. Whether or not you actually believe this, or even if it seems difficult to believe, we would simply like you to imagine that it is true, and try your best to think of a reason for it and complete the following sentence: <br>I deserve more than others because...",
                rows:1},

            {type:'textarea',
            name: 'hient3',
            required: true,
               stem: "<p><br></b>Lastly, we would like you to take the perspective that you should expect to get your own way in life. Whether or not you actually believe this, or even if it seems difficult to believe, we would simply like you to imagine that it is true, and try your best to think of a reason for it and complete the following sentence: <br>I should expect to get my own way in life because...",
                rows:1

            }

    ]}]);

 
return API.script;
});




















































