define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest'});

    API.addPagesSet('progressBar', [
	{progressBar: '<h4><br><br>Now we would like you to take a certain perspective on yourself and respond accordlingly.',
numbered: false,
required: true,
        decline: true,
			v1style:2}]);


API.addSequence([


        {inherit: 'progressBar',
         questions: [
            {type:'textarea',
            name: 'lowent1',
            required: true,
stem: "<p><br></b>First, we would like you to take the perspective that you should not demand the best in life. Whether or not you actually believe this, or even if it seems difficult to believe, we would simply like you to imagine that it is true, and try your best to think of a reason for it and complete the following sentence: <br>I should not demand the best in life because...",
               rows:1},

            {type:'textarea',
            name: 'lowent2',
            required: true,
               stem: "<p><br></b>Next, we would like you to take the perspective that you do not deserve more than others. Whether or not you actually believe this, or even if it seems difficult to believe, we would simply like you to imagine that it is true, and try your best to think of a reason for it and complete the following sentence: <br>I do not deserve more than others because...",
                rows:1},

            {type:'textarea',
            name: 'lowent3',
            required: true,
               stem: "<p><br></b>Lastly, we would like you to take the perspective that you should not expect to get your own way in life. Whether or not you actually believe this, or even if it seems difficult to believe, we would simply like you to imagine that it is true, and try your best to think of a reason for it and complete the following sentence: <br>I should not expect to get my own way in life because...",
                rows:1

            }

    ]}]);

 
return API.script;
});

















































