define(['managerAPI'], function(Manager){

// This code is responsible for styling the piQuest tasks as panels (like piMessage)
	// Don't touch unless you know what you're doing
	var API = new Manager();
	API.addSettings('skin', 'demo');
	API.addSettings('skip',true);

	API.setName('mgr');
	API.addGlobal({baseURL : '/implicit/user/uflliz/epo6/images/'});
	API.addTasksSet({
		instructions: [{type:'message', buttonText:'Continue'}], 
		
		consent : [{inherit:'instructions', name:'consent', templateUrl: 'consent.jst', title:'Consent', 
			piTemplate:true, header:'Consent Agreement: Implicit Social Cognition on the Internet'}],
		
		realstart : [{
			inherit:'instructions', name:'realstart', templateUrl: 'realstart.jst', piTemplate:true}], 


	goalpost1a : [{
			inherit:'instructions', name:'goalpost1a', templateUrl: 'goalpost1a.jst', piTemplate:true}], 
	
		goalpost1b : [{
			inherit:'instructions', name:'goalpost1b', templateUrl: 'goalpost1b.jst', piTemplate:true}], 
	
	
	goalpost2 : [{
			inherit:'instructions', name:'goalpost2', templateUrl: 'goalpost2.jst', piTemplate:true}], 
	
	
	lowent: [{type: 'quest', name: 'lowent', scriptUrl: 'lowent.js'}],
	hient: [{type: 'quest', name: 'hient', scriptUrl: 'hient.js'}],


		longsvs: [{type: 'quest', name: 'longsvs', scriptUrl: 'longsvs.js'}],
				
		statusresmot: [{type: 'quest', name: 'statusresmot', scriptUrl: 'statusresmot.js'}],
		retribjorient: [{type: 'quest', name: 'retribjorient', scriptUrl: 'retribjorient.js'}],
		crimethreat: [{type: 'quest', name: 'crimethreat', scriptUrl: 'crimethreat.js'}],
		
	instiatrace: [{inherit:'instructions', name:'iatinstrace', templateUrl: 'instiatrace.jst', title:'IAT Instructions',
			      piTemplate:true, header:'Implicit Association Test'}],
                    
		
		iatrace: [{type: 'pip', name: 'iatrace', version: '0.3', scriptUrl: 'iatrace.js'}], 
		  

		debriefing : [{type:'message',name:'lastpage', templateUrl: 'debriefing.jst', piTemplate:'debrief', last:true}]
});

	

	API.addSequence([
	
{inherit:'consent'},
{inherit:'realstart'},

{mixer:'choose',
		 n:1,
		data : [                		
		            {inherit:'hient'},
                    {inherit:'lowent'}
			]},

{inherit:'goalpost1a'},	
{inherit:'longsvs'},	

{inherit:'goalpost1b'},	

    		{mixer:'random', data : [
               		{inherit:'statusresmot'},
               		{inherit:'crimethreat'},
                    {inherit:'retribjorient'}
    		]},
    	
{inherit:'goalpost2'},	

	{inherit:'instiatrace'},
	{inherit:'iatrace'},	

	{inherit:'debriefing'}

		
]);


		
	return API.script;
});





















































































